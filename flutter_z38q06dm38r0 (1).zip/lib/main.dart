import 'package:flutter/material.dart';

class Counter extends StatelessWidget{
  final void Function()

  incrementCounter;
  const Counter({
    super.key,
    required this.incrementCounter
  });

  @override
  Widget build(BuildContext context){
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        ElevatedButton(
          onPressed: incrementCounter,
          child: const Text('Increment'),
        ),
          const SizedBox(width: 16),
          const Text('Count: '),
      ],
    );
  }
}

class CounterApp extends StatefulWidget {

  const CounterApp({
    super.key});

  @override
  State<CounterApp> createState() => _CounterAppState();
}

class _CounterAppState extends State<CounterApp> {
  int _counter = 0;

  void _increment() {
    setState(() {

      _counter++;
    });
  }
 @override
  Widget build(BuildContext context) {

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        ElevatedButton(
          onPressed: _increment,
          child: const Text('Increment'),
        ),
        const SizedBox(width: 16),
        Text('Count: $_counter'),
      ],
    );
  }
}
void main() {
  runApp(
    const MaterialApp(
      home: Scaffold(
        body: Center(
          child: CounterApp(),
        ),
      ),
    ),
  );
}


